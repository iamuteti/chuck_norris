## Installation

Run the following commands:

1. `composer install`
2. `npm install`
3. `php artisan migrate`

### How to start server:

Run the following command: `php artisan serve` then open http://127.0.0.1:8000 in the browser.
