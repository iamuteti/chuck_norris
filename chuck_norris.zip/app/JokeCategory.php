<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JokeCategory extends Model
{
    //
}
