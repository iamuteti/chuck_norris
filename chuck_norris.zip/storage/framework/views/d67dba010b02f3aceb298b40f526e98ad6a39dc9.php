<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Add Joke
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('jokes.update', $joke->id)); ?>">
                  <?php echo method_field('PATCH'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label for="first_name">Title:</label>
                      <input type="text" class="form-control" name="title" value=<?php echo e($joke->title); ?> />
                  </div>
                  <div class="form-group">
                                <select class="form-control" name="categories[]" multiple="multiple">
                                  <option>Select categories</option>
                                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                     <?php if($joke->categories->containsStrict('id', $category->id)): ?> selected="selected" <?php endif; ?>
                                    >
                                        <?php echo e($category->name); ?>

                                    </option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                  <div class="form-group">
                      <label for="last_name">Date:</label>
                      <input type="date" class="form-control" name="date" value=<?php echo e($joke->date); ?> />
                  </div>
                  <button type="submit" class="btn btn-primary">Update</button>
              </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chuck_norris\resources\views/jokes/edit.blade.php ENDPATH**/ ?>